System Requirements:
Microsoft Windows 7 or newer
mySQL Workbench


--------------------------------------initial configuration---------------------------------------
Create a new database in mysql workbench. 
The database name should be test. 

Create a new user with the following information.
The credentials should be:
	user: admin
	pass: admin
	
The .ibd files contained in the "database files" folder are the tables used for the database. They typically reside in C:\ProgramData\MySQL\MySQL Server 8.0\Data\<Database name goes here>
You would want to copy the .ibd files provided into C:\ProgramData\MySQL\MySQL Server 8.0\Data\test

---------------------------------------------------------------------------------------------------

There is a compiled .exe in the "Compiled Program" folder. You can run this if you are unable to open the project into Visual Studio.
You will need to have the mysql database running, however.


The source code to the project is contained in the "BDCMovieDB1" folder. If you have Visual Studio installed, you should be able to open BDCMovieDB1.sln, which will load all necessary packages needed to communicate with the mysql database


The "images" folder contains images of the program in operation, along with a .txt file with descriptions. 








Crafted with love by David Osterhoff, Binju Shrestha, and Chenson Johnson