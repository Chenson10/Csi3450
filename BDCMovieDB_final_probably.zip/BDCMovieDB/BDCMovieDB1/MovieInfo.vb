﻿Imports System.Data.OleDb
Imports MySql.Data.MySqlClient
Public Class MovieInfo
    Dim connectdb As New MySql.Data.MySqlClient.MySqlConnection
    Dim connectOLE As New OleDbConnection
    Private Sub MovieInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        connectdb.ConnectionString = "server=localhost;userid='admin';password='admin';persistsecurityinfo=True;database=test;"
        connectOLE.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=MovieDatabasePrototype1.mdb"

        connectdb.Open()
        'connectOLE.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        Dim da As New MySqlDataAdapter
        Dim bsource As New BindingSource
        Dim bsource2 As New BindingSource
        Dim dt2 As New DataTable
        Dim ds2 As New DataSet
        ds2.Tables.Add(dt2)
        Dim da2 As New MySqlDataAdapter
        Dim da3 As New OleDbDataAdapter
        Try
            Dim Query As String
            Query = "SELECT peopleName FROM test.people WHERE peopleID = ANY (SELECT peopleID FROM test.directs WHERE movieName like '%" & lblMovieName.Text & "%')"
            Dim Command = New MySqlCommand(Query, connectdb)
            da.SelectCommand = Command
            da.Fill(dt)
            bsource.DataSource = dt
            DataGridView1.DataSource = bsource
            'da.Update(dt)
            'da3 = New OleDbDataAdapter("SELECT peopleName FROM people WHERE peopleID = ANY (SELECT peopleID FROM Directs WHERE movieName like '%" & lblMovieName.Text & "%')", connectOLE)
            'da3.Fill(dt)
            'DataGridView1.DataSource = dt.DefaultView

            Dim Query2 As String
            Query2 = "SELECT peopleName FROM test.people WHERE peopleID = ANY (SELECT peopleID FROM test.starsin WHERE movieName like '%" & lblMovieName.Text & "%')"
            Dim Command2 = New MySqlCommand(Query2, connectdb)
            da2.SelectCommand = Command2
            da2.Fill(dt2)
            bsource2.DataSource = dt2
            DataGridView2.DataSource = bsource2
            da2.Update(dt2)
            'da2 = New OleDbDataAdapter("SELECT peopleName FROM people WHERE peopleID = ANY (SELECT peopleID FROM StarsIn WHERE movieName like '%" & lblMovieName.Text & "%')", connectdb)
            'da2.Fill(dt2)
            'DataGridView2.DataSource = dt2.DefaultView

            connectdb.Close()
            'connectOLE.Close()
        Catch
            MessageBox.Show("an error occured")
        End Try


    End Sub

    'Private Sub selectCell(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
    '    Dim selectedRowIndex As Integer
    '    selectedRowIndex = e.RowIndex
    '    Dim row As New DataGridViewRow()

    '    row = DataGridView1.Rows(selectedRowIndex)


    'End Sub

    'Private Sub selectCell2(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellClick


    'End Sub

End Class