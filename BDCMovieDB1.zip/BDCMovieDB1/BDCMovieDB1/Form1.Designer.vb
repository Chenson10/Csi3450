﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.searchBox = New System.Windows.Forms.TextBox()
        Me.boxSearchMode = New System.Windows.Forms.ComboBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.lbl8 = New System.Windows.Forms.Label()
        Me.lblProduction = New System.Windows.Forms.Label()
        Me.lblServices = New System.Windows.Forms.Label()
        Me.lblProducedby = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'searchBox
        '
        Me.searchBox.Location = New System.Drawing.Point(212, 25)
        Me.searchBox.Margin = New System.Windows.Forms.Padding(2)
        Me.searchBox.Name = "searchBox"
        Me.searchBox.Size = New System.Drawing.Size(167, 20)
        Me.searchBox.TabIndex = 0
        '
        'boxSearchMode
        '
        Me.boxSearchMode.FormattingEnabled = True
        Me.boxSearchMode.Location = New System.Drawing.Point(38, 25)
        Me.boxSearchMode.Margin = New System.Windows.Forms.Padding(2)
        Me.boxSearchMode.Name = "boxSearchMode"
        Me.boxSearchMode.Size = New System.Drawing.Size(92, 21)
        Me.boxSearchMode.TabIndex = 1
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(20, 71)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(2)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(554, 175)
        Me.DataGridView1.TabIndex = 2
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(20, 263)
        Me.lbl1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(72, 24)
        Me.lbl1.TabIndex = 3
        Me.lbl1.Text = "Label1"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2.Location = New System.Drawing.Point(20, 295)
        Me.lbl2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(57, 20)
        Me.lbl2.TabIndex = 4
        Me.lbl2.Text = "Label2"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3.Location = New System.Drawing.Point(20, 327)
        Me.lbl3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(57, 20)
        Me.lbl3.TabIndex = 5
        Me.lbl3.Text = "Label3"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4.Location = New System.Drawing.Point(20, 359)
        Me.lbl4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(57, 20)
        Me.lbl4.TabIndex = 6
        Me.lbl4.Text = "Label4"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5.Location = New System.Drawing.Point(20, 391)
        Me.lbl5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(57, 20)
        Me.lbl5.TabIndex = 7
        Me.lbl5.Text = "Label5"
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6.Location = New System.Drawing.Point(20, 423)
        Me.lbl6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(57, 20)
        Me.lbl6.TabIndex = 8
        Me.lbl6.Text = "Label6"
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(382, 25)
        Me.btnSearch.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(86, 21)
        Me.btnSearch.TabIndex = 9
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'lblCount
        '
        Me.lblCount.AutoSize = True
        Me.lblCount.Location = New System.Drawing.Point(508, 248)
        Me.lblCount.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(34, 13)
        Me.lblCount.TabIndex = 10
        Me.lblCount.Text = "count"
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7.Location = New System.Drawing.Point(20, 455)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(57, 20)
        Me.lbl7.TabIndex = 11
        Me.lbl7.Text = "Label7"
        '
        'lbl8
        '
        Me.lbl8.AutoSize = True
        Me.lbl8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8.Location = New System.Drawing.Point(20, 487)
        Me.lbl8.Name = "lbl8"
        Me.lbl8.Size = New System.Drawing.Size(57, 20)
        Me.lbl8.TabIndex = 12
        Me.lbl8.Text = "Label8"
        '
        'lblProduction
        '
        Me.lblProduction.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblProduction.AutoSize = True
        Me.lblProduction.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProduction.Location = New System.Drawing.Point(328, 299)
        Me.lblProduction.MaximumSize = New System.Drawing.Size(0, 30)
        Me.lblProduction.MinimumSize = New System.Drawing.Size(260, 0)
        Me.lblProduction.Name = "lblProduction"
        Me.lblProduction.Size = New System.Drawing.Size(260, 16)
        Me.lblProduction.TabIndex = 13
        Me.lblProduction.Text = "production"
        Me.lblProduction.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblServices
        '
        Me.lblServices.AutoSize = True
        Me.lblServices.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblServices.Location = New System.Drawing.Point(411, 497)
        Me.lblServices.Name = "lblServices"
        Me.lblServices.Size = New System.Drawing.Size(177, 18)
        Me.lblServices.TabIndex = 14
        Me.lblServices.Text = "Where Can I Watch It?"
        '
        'lblProducedby
        '
        Me.lblProducedby.AutoSize = True
        Me.lblProducedby.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProducedby.Location = New System.Drawing.Point(500, 277)
        Me.lblProducedby.Name = "lblProducedby"
        Me.lblProducedby.Size = New System.Drawing.Size(88, 16)
        Me.lblProducedby.TabIndex = 15
        Me.lblProducedby.Text = "Produced by:"
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 524)
        Me.Controls.Add(Me.lblProducedby)
        Me.Controls.Add(Me.lblServices)
        Me.Controls.Add(Me.lblProduction)
        Me.Controls.Add(Me.lbl8)
        Me.Controls.Add(Me.lbl7)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.lbl6)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.boxSearchMode)
        Me.Controls.Add(Me.searchBox)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "FormMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "BDC Movie Database"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents searchBox As TextBox
    Friend WithEvents boxSearchMode As ComboBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents lbl1 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl3 As Label
    Friend WithEvents lbl4 As Label
    Friend WithEvents lbl5 As Label
    Friend WithEvents lbl6 As Label
    Friend WithEvents btnSearch As Button
    Friend WithEvents lblCount As Label
    Friend WithEvents lbl7 As Label
    Friend WithEvents lbl8 As Label
    Friend WithEvents lblProduction As Label
    Friend WithEvents lblServices As Label
    Friend WithEvents lblProducedby As Label
End Class
