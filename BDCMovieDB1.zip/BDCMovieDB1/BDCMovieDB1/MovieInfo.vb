﻿Imports System.Data.OleDb
Public Class MovieInfo
    Dim connectdb As New OleDbConnection
    Private Sub MovieInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connectdb.ConnectionString = "provider=microsoft.jet.oledb.4.0; data source = MovieDatabasePrototype1.mdb"

        connectdb.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        Dim da As New OleDbDataAdapter
        Dim dt2 As New DataTable
        Dim ds2 As New DataSet
        ds2.Tables.Add(dt2)
        Dim da2 As New OleDbDataAdapter
        Try
            da = New OleDbDataAdapter("SELECT peopleName FROM people WHERE peopleID = ANY (SELECT peopleID FROM Directs WHERE movieName like '%" & lblMovieName.Text & "%')", connectdb)
            da.Fill(dt)
            DataGridView1.DataSource = dt.DefaultView

            da2 = New OleDbDataAdapter("SELECT peopleName FROM people WHERE peopleID = ANY (SELECT peopleID FROM StarsIn WHERE movieName like '%" & lblMovieName.Text & "%')", connectdb)
            da2.Fill(dt2)
            DataGridView2.DataSource = dt2.DefaultView

            connectdb.Close()
        Catch
            MessageBox.Show("an error occured")
        End Try


    End Sub

    'Private Sub selectCell(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
    '    Dim selectedRowIndex As Integer
    '    selectedRowIndex = e.RowIndex
    '    Dim row As New DataGridViewRow()

    '    row = DataGridView1.Rows(selectedRowIndex)


    'End Sub

    'Private Sub selectCell2(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellClick


    'End Sub

End Class