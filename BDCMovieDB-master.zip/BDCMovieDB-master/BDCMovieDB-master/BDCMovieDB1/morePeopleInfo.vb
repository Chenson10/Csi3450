﻿Imports System.Data.OleDb
Public Class morePeopleInfo
    Dim connectdb As New OleDbConnection
    Private Sub morePeopleInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connectdb.ConnectionString = "provider=microsoft.jet.oledb.4.0; data source = MovieDatabasePrototype1.mdb"

        connectdb.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        Dim da As New OleDbDataAdapter
        Dim dt2 As New DataTable
        Dim ds2 As New DataSet
        ds2.Tables.Add(dt2)
        Dim da2 As New OleDbDataAdapter
        Try
            da = New OleDbDataAdapter("SELECT movieName FROM Directs WHERE peopleID = ANY (SELECT peopleID FROM People WHERE peopleName like '%" & lblName.Text & "%')", connectdb)
            da.Fill(dt)
            directsGrid.DataSource = dt.DefaultView

            da2 = New OleDbDataAdapter("SELECT movieName FROM StarsIn WHERE peopleID = ANY (SELECT peopleID FROM People WHERE peopleName like '%" & lblName.Text & "%')", connectdb)
            da2.Fill(dt2)
            starsGrid.DataSource = dt2.DefaultView

            connectdb.Close()
        Catch
            MessageBox.Show("an error occured")
        End Try

    End Sub
End Class