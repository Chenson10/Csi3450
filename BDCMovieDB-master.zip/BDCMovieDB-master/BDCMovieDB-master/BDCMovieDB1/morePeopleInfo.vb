﻿Imports System.Data.OleDb
Public Class morePeopleInfo
    Dim connectdb As New MySql.Data.MySqlClient.MySqlConnection
    Private Sub morePeopleInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connectdb.ConnectionString = "server=localhost;userid='Akari';password='admin';persistsecurityinfo=True;database=test;"

        connectdb.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        Dim da As New MySqlDataAdapter
        Dim dt2 As New DataTable
        Dim ds2 As New DataSet
        ds2.Tables.Add(dt2)
        Dim da2 As New MySqlDataAdapter
        Try
            Dim Query As String
            Query = "SELECT movieName FROM Directs WHERE peopleID = ANY (SELECT peopleID FROM People WHERE peopleName like '%" & lblName.Text & "%'"
            Dim Command = New MySqlCommand(Query, connectdb)
            da.SelectCommand = Command
            da.Fill(dt)
            bSource.DataSource = dt
            DataGridView1.DataSource = bSource
            da.Update(dt)
            'da = New MySqlDataAdapter("SELECT movieName FROM Directs WHERE peopleID = ANY (SELECT peopleID FROM People WHERE peopleName like '%" & lblName.Text & "%')", connectdb)
            'da.Fill(dt)
            'directsGrid.DataSource = dt.DefaultView

            Dim Query As String
            Query = "SELECT movieName FROM StarsIn WHERE peopleID = ANY (SELECT peopleID FROM People WHERE peopleName like '%" & lblName.Text & "%'"
            Dim Command = New MySqlCommand(Query, connectdb)
            da2.SelectCommand = Command
            da2.Fill(dt2)
            bSource.DataSource = dt2
            DataGridView1.DataSource = bSource
            da2.Update(dt2)
            'da2 = New OleDbDataAdapter("SELECT movieName FROM StarsIn WHERE peopleID = ANY (SELECT peopleID FROM People WHERE peopleName like '%" & lblName.Text & "%')", connectdb)
            'da2.Fill(dt2)
            'starsGrid.DataSource = dt2.DefaultView

            connectdb.Close()
        Catch
            MessageBox.Show("an error occured")
        End Try

    End Sub
End Class