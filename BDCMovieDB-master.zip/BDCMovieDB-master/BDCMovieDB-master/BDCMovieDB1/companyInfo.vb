﻿Imports System.Data.OleDb
Public Class companyInfo
    Dim connectdb As New MySql.Data.MySqlClient.MySqlConnection
    Private Sub companyInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connectdb.ConnectionString = "server=localhost;userid='Akari';password='admin';persistsecurityinfo=True;database=test;"

        connectdb.Open()
        Dim da As New MySqlDataAdapter
        Dim dt As New DataTable
        Dim bSource As New BindingSource
        Dim ds As New DataSet
        ds.Tables.Add(dt)

        Try
            Dim Query As String
            Query = "SELECT MovieName FROM Production WHERE CompanyName like '%" & lblCompanyName.Text & "%'"
            Dim Command = New MySqlCommand(Query, connectdb)
            da.SelectCommand = Command
            da.Fill(dt)
            bSource.DataSource = dt
            DataGridView1.DataSource = bSource
            da.Update(dt)
            'da = New OleDbDataAdapter("SELECT MovieName FROM Production WHERE CompanyName like '%" & lblCompanyName.Text & "%'", connectdb)
            'da.Fill(dt)
            'movieGrid.DataSource = dt.DefaultView

            connectdb.Close()
        Catch
            MessageBox.Show("an error occured")
        End Try
    End Sub
End Class