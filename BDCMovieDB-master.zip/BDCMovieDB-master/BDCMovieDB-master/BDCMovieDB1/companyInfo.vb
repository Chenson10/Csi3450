﻿Imports System.Data.OleDb
Public Class companyInfo
    Dim connectdb As New OleDbConnection
    Private Sub companyInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connectdb.ConnectionString = "provider=microsoft.jet.oledb.4.0; data source = MovieDatabasePrototype1.mdb"

        connectdb.Open()
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        Dim da As New OleDbDataAdapter

        Try
            da = New OleDbDataAdapter("SELECT MovieName FROM Production WHERE CompanyName like '%" & lblCompanyName.Text & "%'", connectdb)
            da.Fill(dt)
            movieGrid.DataSource = dt.DefaultView

            connectdb.Close()
        Catch
            MessageBox.Show("an error occured")
        End Try
    End Sub
End Class