﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class morePeopleInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.directsGrid = New System.Windows.Forms.DataGridView()
        Me.starsGrid = New System.Windows.Forms.DataGridView()
        CType(Me.directsGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.starsGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 63)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Directs"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(260, 63)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Stars In"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(110, 9)
        Me.lblName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblName.MinimumSize = New System.Drawing.Size(260, 0)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(260, 24)
        Me.lblName.TabIndex = 4
        Me.lblName.Text = "Label3"
        Me.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'directsGrid
        '
        Me.directsGrid.AllowUserToAddRows = False
        Me.directsGrid.AllowUserToDeleteRows = False
        Me.directsGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.directsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.directsGrid.Location = New System.Drawing.Point(28, 87)
        Me.directsGrid.Name = "directsGrid"
        Me.directsGrid.ReadOnly = True
        Me.directsGrid.Size = New System.Drawing.Size(202, 122)
        Me.directsGrid.TabIndex = 5
        '
        'starsGrid
        '
        Me.starsGrid.AllowUserToAddRows = False
        Me.starsGrid.AllowUserToDeleteRows = False
        Me.starsGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.starsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.starsGrid.Location = New System.Drawing.Point(257, 87)
        Me.starsGrid.Name = "starsGrid"
        Me.starsGrid.ReadOnly = True
        Me.starsGrid.Size = New System.Drawing.Size(202, 122)
        Me.starsGrid.TabIndex = 6
        '
        'morePeopleInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(486, 242)
        Me.Controls.Add(Me.starsGrid)
        Me.Controls.Add(Me.directsGrid)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "morePeopleInfo"
        Me.Text = "morePeopleInfo"
        CType(Me.directsGrid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.starsGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblName As Label
    Friend WithEvents directsGrid As DataGridView
    Friend WithEvents starsGrid As DataGridView
End Class
