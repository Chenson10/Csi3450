﻿Imports System.Data.OleDb
Imports MySql.Data.MySqlClient

Public Class FormMain
    Dim connectdb As New MySql.Data.MySqlClient.MySqlConnection

    Dim searchMode As String = "Movies"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        connectdb.ConnectionString = "server=localhost;userid='Akari';password='admin';persistsecurityinfo=True;database=test;"

        boxSearchMode.Items.Add("Company")
        boxSearchMode.Items.Add("People")
        boxSearchMode.Items.Add("Movies")

        lblProducedby.Text = ""
        lblServices.Text = ""
        lblProduction.Text = ""
        lbl1.Text = ""
        lbl2.Text = ""
        lbl3.Text = ""
        lbl4.Text = ""
        lbl5.Text = ""
        lbl6.Text = ""
        lbl7.Text = ""
        lbl8.Text = ""
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        Dim da As New MySqlDataAdapter
        Dim dt As New DataTable
        Dim bSource As New BindingSource
        Dim ds As New DataSet
        ds.Tables.Add(dt)


        Select Case searchMode
            Case "Company"
                Try
                    connectdb.Open()
                    Dim Query As String
                    Query = "select * from Company where companyName like'%" & searchBox.Text & "%'"
                    Dim Command = New MySqlCommand(Query, connectdb)
                    da.SelectCommand = Command
                    da.Fill(dt)
                    bSource.DataSource = dt
                    DataGridView1.DataSource = bSource
                    da.Update(dt)

                    connectdb.Close()
                Catch
                    connectdb.Close()
                    MessageBox.Show("An error happened with the mySQL connection.")
                    searchBox.Text = ""
                End Try
            Case "People"
                Try
                    'da = New OleDbDataAdapter("select * from people where peopleName like'%" & searchBox.Text & "%'", connectdb)
                    'da.Fill(dt)
                    'DataGridView1.DataSource = dt.DefaultView 'used for a visual database. might delete later. It fills datagridview1 with the generated table
                    'connectdb.Close()
                Catch
                    connectdb.Close()
                    MessageBox.Show("An error happened.")
                    searchBox.Text = ""
                End Try
            Case "Movies"
                Try
                    'da = New OleDbDataAdapter("select * from Movie where movieName like'%" & searchBox.Text & "%'", connectdb)
                    'da.Fill(dt)
                    'DataGridView1.DataSource = dt.DefaultView 'used for a visual database. might delete later. It fills datagridview1 with the generated table
                    'connectdb.Close()
                Catch
                    connectdb.Close()
                    MessageBox.Show("An error happened.")
                    searchBox.Text = ""
                End Try

            Case Else

        End Select

        lblCount.Text = DataGridView1.RowCount & " items"

    End Sub

    Private Sub boxSearchMode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles boxSearchMode.SelectedIndexChanged
        searchMode = boxSearchMode.Text
        Console.WriteLine(searchMode)
    End Sub

    Private Sub selectCell(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        Dim selectedRowIndex As Integer
        selectedRowIndex = e.RowIndex
        Dim row As New DataGridViewRow()

        row = DataGridView1.Rows(selectedRowIndex)

        Select Case searchMode
            Case "People"
                lblProducedby.Text = ""
                lblServices.Text = ""
                lblProduction.Text = ""
                Try
                    Dim peopleID As String
                    peopleID = row.Cells(0).Value
                    lbl2.Text = "ID # " & peopleID
                Catch ex As Exception
                End Try
                Try
                    Dim peopleName As String
                    peopleName = row.Cells(1).Value
                    lbl1.Text = peopleName
                Catch ex As Exception
                End Try
                Try
                    Dim DoB As String
                    DoB = row.Cells(2).Value
                    lbl3.Text = DoB
                Catch ex As Exception
                End Try
                lbl4.Text = ""
                lbl5.Text = ""
                lbl6.Text = ""
                lbl7.Text = ""
                lbl8.Text = ""
            Case "Company"
                lblProducedby.Text = ""
                lblServices.Text = ""
                lblProduction.Text = ""
                Try
                    Dim companyName As String
                    companyName = row.Cells(0).Value
                    lbl1.Text = companyName
                Catch ex As Exception
                End Try
                Try
                    Dim companyCountry As String
                    companyCountry = row.Cells(1).Value
                    lbl2.Text = companyCountry
                Catch ex As Exception
                End Try
                lbl3.Text = ""
                lbl4.Text = ""
                lbl5.Text = ""
                lbl6.Text = ""
                lbl7.Text = ""
                lbl8.Text = ""
            Case "Movies"
                lblProducedby.Text = "Produced by:"
                lblServices.Text = "Where Can I Watch It?"
                Try
                    Dim movieName As String
                    movieName = row.Cells(0).Value
                    lbl1.Text = movieName
                Catch ex As Exception
                End Try
                Try
                    Dim dateRelease As String
                    dateRelease = row.Cells(1).Value
                    lbl2.Text = "Released on " & dateRelease
                Catch ex As Exception
                End Try
                Try
                    Dim budget As Decimal
                    budget = row.Cells(2).Value
                    Dim budgetString As String
                    budgetString = String.Format("Total Budget: {0:C2}", budget)
                    Console.WriteLine(budgetString)
                    lbl3.Text = budgetString
                Catch ex As Exception
                End Try
                Try
                    Dim revenue As Decimal
                    revenue = row.Cells(3).Value
                    Dim revenueString As String
                    revenueString = String.Format("Total Revenue: {0:C2}", revenue)
                    Console.WriteLine(revenueString)
                    lbl4.Text = revenueString
                Catch ex As Exception
                End Try
                Try
                    Dim ageRating As String
                    ageRating = row.Cells(4).Value
                    lbl5.Text = "Rated: " & ageRating
                Catch ex As Exception
                End Try
                Try
                    Dim runTime As String
                    runTime = row.Cells(5).Value
                    lbl6.Text = runTime & " minutes"
                Catch ex As Exception
                End Try
                Try
                    Dim critRating As String
                    critRating = row.Cells(6).Value
                    lbl7.Text = "Critics rated it " & critRating & "%"
                Catch ex As Exception
                End Try
                Try
                    Dim audiRating As String
                    audiRating = row.Cells(7).Value
                    lbl8.Text = "Audience rated it " & audiRating & "%"
                Catch ex As Exception
                End Try
                Try
                    'This looks up the company
                    connectdb.Open()
                    Dim companyName As String = "null"
                    Dim selectedrow As DataRow
                    Dim dt1 As New DataTable
                    Dim ds1 As New DataSet
                    ds1.Tables.Add(dt1)
                    Dim daACVar As New OleDbDataAdapter
                    'daACVar = New OleDbDataAdapter("SELECT * from Production WHERE MovieName like '%" & lbl1.Text & "%'", connectdb)
                    daACVar.Fill(dt1)
                    selectedrow = dt1.Rows.Item(0)
                    companyName = selectedrow.Item(1)
                    connectdb.Close()
                    lblProduction.TextAlign = ContentAlignment.MiddleRight
                    lblProduction.Text = companyName
                Catch ex As Exception
                    connectdb.Close()
                    MessageBox.Show("An error occured while searching the database")
                    lblProduction.Text = CompanyName
                End Try

            Case Else
                MessageBox.Show("you should never see this message. If you do see it, please pray to the deity of your choice and ask for the wisdom needed to figure this out")
        End Select

    End Sub

    Public Sub lblServices_Click(sender As Object, e As EventArgs) Handles lblServices.Click

        Dim moviename As String = lbl1.Text
        Dim ServicesWindow As New AvailableServices()
        ServicesWindow.lblMovieName.Text = moviename
        ServicesWindow.Show()
        Console.WriteLine(moviename)

    End Sub

    Public Sub lbl1_Click(sender As Object, e As EventArgs) Handles lbl1.Click
        Select Case searchMode
            Case "People"
                Dim peopleName As String = lbl1.Text
                Dim peopleInfo As New morePeopleInfo()
                peopleInfo.lblName.Text = peopleName
                peopleInfo.Show()

            Case "Movies"
                Dim moviename As String = lbl1.Text
                Dim movieInfo As New MovieInfo()
                movieInfo.lblMovieName.Text = moviename
                movieInfo.Show()

            Case "Company"
                Dim companyname As String = lbl1.Text
                Dim companyInfo As New companyInfo()
                companyInfo.lblCompanyName.Text = companyname
                companyInfo.Show()
            Case Else

        End Select
    End Sub



End Class
