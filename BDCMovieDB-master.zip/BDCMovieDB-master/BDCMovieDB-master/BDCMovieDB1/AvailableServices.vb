﻿Imports System.Data.OleDb
Public Class AvailableServices
    Dim connectdb As New MySql.Data.MySqlClient.MySqlConnection

    Public Sub AvailableServices_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        connectdb.ConnectionString = "server=localhost;userid='Akari';password='admin';persistsecurityinfo=True;database=test;"

        connectdb.Open()
        Dim da As New MySqlDataAdapter
        Dim dt As New DataTable
        Dim bSource As New BindingSource
        Dim ds As New DataSet
        ds.Tables.Add(dt)

        Dim Query As String
        Query = "SELECT serviceName FROM AvailableOn where movieName like'%" & lblMovieName.Text & "%'"
        Dim Command = New MySqlCommand(Query, connectdb)
        da.SelectCommand = Command
        da.Fill(dt)
        bSource.DataSource = dt
        DataGridView1.DataSource = bSource
        da.Update(dt)

        connectdb.Close()


    End Sub
End Class